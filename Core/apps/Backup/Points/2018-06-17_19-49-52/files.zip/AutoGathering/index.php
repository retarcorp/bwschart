<!DOCTYPE html>
<html>
<head>
    
</head>
<body>
    <script src='autoCandlesInserting.js'></script>
</body>