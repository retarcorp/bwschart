<?php

namespace Core\Classes\System;

class RSqlCredentials{
    const DB_HOSTNAME = "127.0.0.1";
    const DB_USERNAME = "admin";
    const DB_PASSWORD = "YxeWNGNXQIyaECHz";
    const DB_DATABASE = "BWSChart";
}