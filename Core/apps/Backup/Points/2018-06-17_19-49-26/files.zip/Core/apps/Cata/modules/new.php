<fieldset class='first'>
	<h2> Выберите название для каталога </h2>
	<label> <input type='text' id='catalogName' /> <span class='stat'> </span></label>
</fieldset>

<fieldset class='second'>
	<h2> Выберите глубину каталога</h2>
	<label> <input type='radio' checked name='nest' value=1/> <span class='ttl'> 1 </span> </label>
	<label> <input type='radio' name='nest' value=2 /> <span class='ttl'> 2 </span> </label>
	<label> <input type='radio' name='nest' value=3 /> <span class='ttl'> 3 </span> </label>
	<label> <input type='radio' name='nest' value=4 /> <span class='ttl'> 4 </span> </label>
	<label> <input type='radio' name='nest' value=5 /> <span class='ttl'> 5 </span> </label>
	<label> <input type='radio' name='nest' value=6 /> <span class='ttl'> 6 </span> </label>
	<label> <input type='button' id='moreNest' value='Больше'/> </label>
	<p>
		<input type='button' id='next' value='Далее'/>
	</p>
</fieldset>
