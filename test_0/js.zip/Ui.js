var Ui = {
    
    parentModal: null,
    
    visualSettingsModal: null,
    
    visualSettingsBtn: null, //кнопка меню
    
    timeframeSettingsBtn: null,
    
    deltaSettingsBtn: null,
    
    instrumentBtn: null,
    
    graphTypeBtn: null,
    
    spritesBtn: null,
    
    indicatorsBtn: null,
    
    menu:null,
    
    innerMenu: null,
    
    helpler: null,
    
    visualSettingsBtns: null, //инпуты модального окна
    
    help_bar: null,
    
    clickEvent: null,
    
    CurrentInstrBlock: null,
    
    flag: true,
    
    lastPressedBtn: {
        instrument: null,
        timeframe: null,
        delta: null
    },
    
    typeOfGraphStruct: {
        footprint: null,
        deltaGraph: null,
        footprintBtn: null,
        deltaGraphBtn: null
    },
    
    init: function(){
        
        // this.clickEvent = new Event('touchstart');
        
        t = this;
        
        this.help_bar = {
            bar: document.getElementById('help_bar'),
            text_box: document.getElementById('help_text')
        }
        
        this.helpler = document.getElementById('helpler');
        this.parentModal = document.getElementById('parent_modal');
        this.visualSettingsModal = document.getElementById('visual_settings-modal');
        this.visualSettingsBtn = document.getElementById('visual_settings');
        this.instrumentBtn = document.getElementById('instrument');
        this.graphTypeBtn = document.getElementById('tools');
        
        this.visualSettingsBtns = {
            colorSprites: document.getElementById('color-sprites'),
            colorCandleOutline: document.getElementById('color-candle-outline'),
            colorPlus: document.getElementById('color-plus'),
            colorMinus: document.getElementById('color-minus'),
            colorBG: document.getElementById('color-background'),
            colorGrid: document.getElementById('color-grid'),
            colorText: document.getElementById('color-text')
        };
        
        this.lastPressedBtn = {
            instrument: document.getElementById('EUR'),
            timeframe: document.getElementById('M1'),
            delta: document.getElementById('hundred')
        };
        
        this.typeOfGraphStruct = {
            footprint: document.getElementById('footprint'),
            deltaGraph: document.getElementById('deltaGraph'),
            footprintBtn: document.getElementById('FOOTPRINT'),
            deltaGraphBtn: document.getElementById('DELTA')
        };
        
        this.setVisualSettingsColor();
        
        this.timeframeSettingsBtn = document.getElementById('timeframe');
        this.deltaSettingsBtn = document.getElementById('delta');
        this.spritesBtn = document.getElementById('sprites');
        this.indicatorsBtn = document.getElementById('indicators');
        
        this.menu = document.getElementById('menu-settings');
        this.innerMenu = document.getElementsByClassName('inner-menu');
        this.about = document.getElementById('about');
        
        this.visualSettingsBtn.addEventListener('click', this.changeVisualSettings);
        this.timeframeSettingsBtn.addEventListener('click', this.changeTimeframe);
        this.deltaSettingsBtn.addEventListener('click', this.changeDelta);
        this.instrumentBtn.addEventListener('click', this.changeInstrument);
        this.graphTypeBtn.addEventListener('click', this.changeGraphType);
        this.parentModal.addEventListener('click', this.onModal.bind(this));
        this.visualSettingsModal.addEventListener('click', this.onVisualSettingsModal);
        // this.about.addEventListener('click', this.onAbout);
        this.menu.addEventListener('click', this.onMenu);
        this.spritesBtn.addEventListener('click', function(e){
            t.drawSprite(e.target.id);
        });
        if(this.flag){
            this.indicatorsBtn.addEventListener('click', this.onIndicators.bind(this));
            this.flag = false;
        }
        this.CurrentInstrBlock = document.getElementById('current-instr');
        this.setCurrentInstrBlock();
    },
    
    addHelpBar: function(target, flag) {
        if(flag){
            // console.warn(typeof target);
            // console.log((target === '' || target === 'sprites' || target === 'move'))
            if(target === '' || target === 'sprites' || target === 'move'){
                // console.log("Ошибка природы")
            }
            else {
                // console.error("Начинаем")
                App.CurrentGraph.Canvas.classList.add('pointer');
                this.help_bar.bar.classList.add('help_bar_move');
                this.help_bar.text_box.classList.remove('hide_modal');
            }
            switch(target) {
                case 'horizontal-line':
                    this.help_bar.text_box.innerText = 'Для установки линии на графике нажмите на нужную строку курсором или пальцем.';
                    break;
                case 'vertical-line': 
                    this.help_bar.text_box.innerText = 'Для установки линии на графике нажмите на нужный столбец курсором или пальцем.';
                    break;
                case 'rectangle':
                    this.help_bar.text_box.innerText = (App.CurrentPlatform === 'PC') ? 'Для создания прямоугольника нажмите и потяните на графике с одного угла, до другого.' : 'Для создания прямоугольника кликните первый раз для установки первой точки грани прямоугольника и второй раз для установки диаметрально-противоположной точки грани.';
                    break;
                case 'market-profile':
                    this.help_bar.text_box.innerText = (App.CurrentPlatform === 'PC') ? 'Для создания прямоугольника нажмите и потяните на графике с одного угла, до другого.' : 'Для создания прямоугольника кликните первый раз для установки первой точки грани прямоугольника и второй раз для установки диаметрально-противоположной точки грани.';
                    break;
                case 'move': 
                    break;
                case 'remove': 
                    this.help_bar.text_box.innerText = 'Для удаления элемента кликните на него(удалится последний добавленный элемент в области клика).';
                    break;
            }
        }
        else {
            // console.error("Завершаем")
            App.CurrentGraph.Canvas.classList.remove('pointer');
            this.help_bar.bar.classList.remove('help_bar_move');
            this.help_bar.text_box.classList.add('hide_modal');
        }
    },
    
    drawSprite: function(target){
        if(target !== 'sprites'){
            Ui.resetHover();
            App.clickForEvent = true;
            App.CurrentGraph.spritesEdditor = true; // = (!App.CurrentGraph.spritesEdditor) ? true : false;
            App.CurrentGraph.currentSprite = target;
            if(target === 'rectangle'){
                App.clickForEvent = true;
            }
            if(target === 'market-profile'){
                App.clickForEvent = true;
            }
            if(target === 'remove_all'){
                App.CurrentGraph.removeAllSprites();
            }
            else {
                this.addHelpBar(App.CurrentGraph.currentSprite, true);
            }
        }
    },
    
    changeVisualSettings: function(e){
        Ui.parentModal.classList.toggle('hide_modal');
        Ui.resetHover();
        e.stopPropagation();
    },
    
    changeTimeframe: function(e){
        Ui.resetHover();
        Data.Request.onXHRChanged();
        if(Ui.lastPressedBtn.timeframe !== null){
            Ui.lastPressedBtn.timeframe.classList.remove('selected');
        }
        e.target.classList.add('selected');
        App.changeTimeframeSettings(e.target);
        App.CurrentGraph.flagForStartPrice = true;
        App.CurrentGraph.GraphSettings.setTimeFrame();
        App.CurrentGraph.GraphSettings.START_TS = Date.now() + App.CurrentGraph.GraphSettings.TIMEFRAME_TS - 7200000;
        Ui.setCurrentInstrBlock();
        App.CurrentGraph.removeAllSprites();
        App.CurrentGraph.recursiveRender();
    },
    
    changeDelta: function(e){
        Ui.resetHover();
        Data.Request.onXHRChanged();
        if(Ui.lastPressedBtn.delta !== null){
            Ui.lastPressedBtn.delta.classList.remove('selected');
        }
        e.target.classList.add('selected');
        Ui.lastPressedBtn.delta = e.target;
        
        Ui.clearCountnerForDeltaGraph();
        
        App.CurrentGraph.flagForStartPrice = true;
        App.changeDeltaSettings(e.target);
        App.CurrentGraph.GraphSettings.setDelta();
        Ui.setCurrentInstrBlock();
        App.CurrentGraph.recursiveRender();
    },
    
    changeInstrument: function(e){
        Ui.resetHover();
        Data.Request.onXHRChanged();
        
        // Data.LastValue = null;
        App.CurrentGraph.IsStartValueNotReceiced = true;
        
        if(Ui.lastPressedBtn.instrument !== null){
            Ui.lastPressedBtn.instrument.classList.remove('selected');
        }
        
        Ui.clearCountnerForDeltaGraph();
        
        e.target.classList.add('selected');
        App.CurrentGraph.flagForStartPrice = true;
        App.changeInstrument(e.target);
        App.CurrentGraph.GraphSettings.setInstrument();
        Ui.setCurrentInstrBlock();
        App.CurrentGraph.recursiveRender();
    },
    
    changeGraphType: function(e){
        Ui.resetHover();
        
        Ui.clearCountnerForDeltaGraph();
        Data.Request.onXHRChanged();
        
        App.CurrentGraph.flagForStartPrice = true;
        if(e.target.innerText === 'DELTA') {
            Ui.typeOfGraphStruct.footprint.classList.add("hide_modal");
            Ui.typeOfGraphStruct.deltaGraph.classList.remove('hide_modal');
            Ui.typeOfGraphStruct.footprintBtn.classList.remove('selected');
            Ui.typeOfGraphStruct.deltaGraphBtn.classList.add('selected');
            
        }
        else if(e.target.innerText === 'FOOTPRINT') {
            Ui.typeOfGraphStruct.footprint.classList.remove("hide_modal");
            Ui.typeOfGraphStruct.deltaGraph.classList.add('hide_modal');
            Ui.typeOfGraphStruct.footprintBtn.classList.add('selected');
            Ui.typeOfGraphStruct.deltaGraphBtn.classList.remove('selected');
        }
        App.init(e.target.innerText, App.CurrentGraph.INSTRUMENT);
    },
    
    clearCountnerForDeltaGraph: function(){
        Data.rightDeltaCandle.ts = -1;
        Data.rightDeltaCandle.index = -9;
        Data.leftDeltaCandle.ts = -1;
        Data.leftDeltaCandle.index = -9;
    },
    
    onModal: function(e){
        Ui.parentModal.classList.add('hide_modal');
    },
    
    onIndicators: function(e) {
        App.CurrentGraph.createIndicator(e.target.innerText);    
    },
    
    onVisualSettingsModal: function(e){
        switch(e.target.id){
            case 'default':
                // console.log(App.CurrentGraph.visualSettings.defaultVisualSettings);
                Ui.getVisualSettingsDefault();
                break;
            case 'ok': 
                App.CurrentGraph.visualSettings.setVisualSettings(
                    Ui.visualSettingsBtns.colorPlus.value,  
                    Ui.visualSettingsBtns.colorMinus.value, 
                    Ui.visualSettingsBtns.colorCandleOutline.value,
                    Ui.visualSettingsBtns.colorBG.value, 
                    Ui.visualSettingsBtns.colorGrid.value, 
                    Ui.visualSettingsBtns.colorText.value,
                    Ui.visualSettingsBtns.colorSprites.value
                    );
                // console.log( App.CurrentGraph.visualSettings);
                Ui.parentModal.classList.toggle('hide_modal');
                App.CurrentGraph.recursiveRender();
                try{
                    // console.warn('save');
                    Data.LocalStorage.save(("visualSettings" + App.CurrentGraph.graphType), App.CurrentGraph.visualSettings);
                }
                catch(err){
                    console.error(err);
                }
                break;
            case 'cansel':
                Ui.visualSettingsBtns.colorSprites.value = App.CurrentGraph.visualSettings.DIR_SPRITES;
                Ui.visualSettingsBtns.colorCandleOutline.value = App.CurrentGraph.visualSettings.DIR_CANDLE_OUTLINE;
                Ui.visualSettingsBtns.colorPlus.value = App.CurrentGraph.visualSettings.DIR_PLUS;
                Ui.visualSettingsBtns.colorMinus.value = App.CurrentGraph.visualSettings.DIR_MINUS;
                Ui.visualSettingsBtns.colorBG.value = App.CurrentGraph.visualSettings.DIR_BG;
                Ui.visualSettingsBtns.colorGrid.value = App.CurrentGraph.visualSettings.DIR_GRID;
                Ui.visualSettingsBtns.colorText.value = App.CurrentGraph.visualSettings.DIR_TEXT;
                Ui.parentModal.classList.toggle('hide_modal');
                break;
        }
        e.stopPropagation();
    },
    
    setVisualSettingsColor: function(){
        try{
            var currentVisualSettings = Data.LocalStorage.get("visualSettings" + App.CurrentGraph.graphType);
            // console.warn("visualSettings" + App.CurrentGraph.graphType,Data.LocalStorage.get("visualSettings" + App.CurrentGraph.graphType))
            if(currentVisualSettings !== null){
                Ui.visualSettingsBtns.colorSprites.value = currentVisualSettings.DIR_SPRITES;
                Ui.visualSettingsBtns.colorCandleOutline.value = currentVisualSettings.DIR_CANDLE_OUTLINE;
                Ui.visualSettingsBtns.colorPlus.value = currentVisualSettings.DIR_PLUS;
                Ui.visualSettingsBtns.colorMinus.value = currentVisualSettings.DIR_MINUS;
                Ui.visualSettingsBtns.colorBG.value = currentVisualSettings.DIR_BG;
                Ui.visualSettingsBtns.colorGrid.value = currentVisualSettings.DIR_GRID;
                Ui.visualSettingsBtns.colorText.value = currentVisualSettings.DIR_TEXT;
                App.CurrentGraph.visualSettings.setVisualSettings(
                    Ui.visualSettingsBtns.colorPlus.value,  
                    Ui.visualSettingsBtns.colorMinus.value, 
                    Ui.visualSettingsBtns.colorCandleOutline.value, 
                    Ui.visualSettingsBtns.colorBG.value, 
                    Ui.visualSettingsBtns.colorGrid.value, 
                    Ui.visualSettingsBtns.colorText.value,
                    Ui.visualSettingsBtns.colorSprites.value
                );
            }
            else{
                this.getVisualSettingsDefault();
            }
        }
        catch(err){
            console.error(err);
        }
    },
    
    getVisualSettingsDefault: function(){
        Ui.visualSettingsBtns.colorSprites.value = App.CurrentGraph.visualSettings.defaultVisualSettings.DIR_SPRITES;
        Ui.visualSettingsBtns.colorCandleOutline.value = App.CurrentGraph.visualSettings.defaultVisualSettings.DIR_CANDLE_OUTLINE;
        Ui.visualSettingsBtns.colorPlus.value = App.CurrentGraph.visualSettings.defaultVisualSettings.DIR_PLUS;
        Ui.visualSettingsBtns.colorMinus.value = App.CurrentGraph.visualSettings.defaultVisualSettings.DIR_MINUS;
        Ui.visualSettingsBtns.colorBG.value = App.CurrentGraph.visualSettings.defaultVisualSettings.DIR_BG;
        Ui.visualSettingsBtns.colorGrid.value = App.CurrentGraph.visualSettings.defaultVisualSettings.DIR_GRID;
        Ui.visualSettingsBtns.colorText.value = App.CurrentGraph.visualSettings.defaultVisualSettings.DIR_TEXT;
    },
    
    onMenu: function(e){
        Ui.parentModal.classList.add('hide_modal');
    },
    
    onAbout: function(){
        Ui.resetHover();
        
    },
    
    resetHover: function(){
        // console.log('reset');
        Ui.menu.classList.add('hide_modal');
        setTimeout(function(){
             Ui.menu.classList.remove('hide_modal');
        }, 200);
        /*
        [].forEach.call(Ui.innerMenu, function(elem) {
            console.log(elem);
            elem.classList.add('hide');
        });
        setTimeout(function(){
            [].forEach.call(Ui.innerMenu, function(elem) {
                elem.classList.remove('hide');
            });
        }, 1000);*/
    },
    
    setCurrentInstrBlock: function() {
        var type = (App.CurrentGraph.type === 'FOOTPRINT') ? App.CurrentGraph.TIMEFRAME.val : App.CurrentGraph.DELTA;
        this.CurrentInstrBlock.innerText = 'BWScharts: ' + App.CurrentGraph.INSTRUMENT + '-' + type;
    }
};