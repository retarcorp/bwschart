var App = {

    CurrentPlatform: 0,
    
    TimezoneOffset: 0,
    
    IsFirstLaunch: true,

    Instrument: {
        EUR: {
            name: '6E',
            step: 0.00005,
            pricePerPx: 0.000002,
            rounding: 5
        },
        GBR: {
            name: '6B',
            step: 0.0001,
            pricePerPx: 0.000004,
            rounding: 4
        },
        JPY: {
            name: '6J',
            step: 0.0000005,
            pricePerPx: 0.00000002,
            rounding: 7
        },
        CHF: {
            name: '6S',
            step: 0.0001,
            pricePerPx: 0.000004,
            rounding: 4
        },
        AUD: {
            name: '6A',
            step: 0.0001,
            pricePerPx: 0.000004,
            rounding: 4
        },
        NZD: {
            name: '6N',
            step: 0.0001,
            pricePerPx: 0.000004,
            rounding: 4
        },
        CAD: {
            name: '6C',
            step: 0.00005,
            pricePerPx: 0.000002,
            rounding: 5
        },
        GOLD: {
            name: 'GC',
            step: 0.1,
            pricePerPx: 0.004,
            rounding: 1
        },
        OIL: {
            name: 'CL',
            step: 0.01,
            pricePerPx: 0.0004,
            rounding: 4
        }
    },
    
    GraphType: {
        FOOTPRINT: 'FOOTPRINT',
        DELTA: 'DELTA'
    },

    CurrentGraph: null,
    
    Canvas: null,
    
    BtnZoomIn: null,

    BtnZoomOut: null, 
    
    ClickForEvent: false,
    
    Flag: true,
    
    LoadGif: null,
    
    changeInstrument: function(instrument){
        App.Debug.log('изменение инструмента');
        Ui.lastPressedBtn.instrument = instrument;
        switch(instrument.innerText){
            case App.Instrument.EUR.name: App.CurrentGraph.setInstrument(App.Instrument.EUR); break;
            case App.Instrument.GBR.name: App.CurrentGraph.setInstrument(App.Instrument.GBR); break;
            case App.Instrument.JPY.name: App.CurrentGraph.setInstrument(App.Instrument.JPY); break;
            case App.Instrument.CHF.name: App.CurrentGraph.setInstrument(App.Instrument.CHF); break;
            case App.Instrument.AUD.name: App.CurrentGraph.setInstrument(App.Instrument.AUD); break;
            case App.Instrument.NZD.name: App.CurrentGraph.setInstrument(App.Instrument.NZD); break;
            case App.Instrument.CAD.name: App.CurrentGraph.setInstrument(App.Instrument.CAD); break;
            case App.Instrument.GOLD.name: App.CurrentGraph.setInstrument(App.Instrument.GOLD); break;
            case App.Instrument.OIL.name: App.CurrentGraph.setInstrument(App.Instrument.OIL); break;
        }
    },
    
    changeTimeframeSettings: function(timeframe){
        App.Debug.log('изменение таймфрейма');
        Ui.lastPressedBtn.timeframe = timeframe;
        var timeframe = Timeframe.getTimeframe(timeframe.innerText);
        App.CurrentGraph.setTimeframe(timeframe);
    },
    
    changeDeltaSettings: function(delta){
        App.Debug.log('изменение дельта');
        var delta = DeltaVal.getDelta(delta.innerText);
        App.CurrentGraph.setDelta(delta);
    },
    
    findLastUsedInstrument: function(instr){
        switch(instr){
            case App.Instrument.EUR.name: return App.Instrument.EUR;
            case App.Instrument.GBR.name: return App.Instrument.GBR;
            case App.Instrument.JPY.name: return App.Instrument.JPY;
            case App.Instrument.CHF.name: return App.Instrument.CHF;
            case App.Instrument.AUD.name: return App.Instrument.AUD;
            case App.Instrument.NZD.name: return App.Instrument.NZD;
            case App.Instrument.CAD.name: return App.Instrument.CAD;
            case App.Instrument.GOLD.name: return App.Instrument.GOLD;
            case App.Instrument.OIL.name: return App.Instrument.OIL;
        }
    },

    init: function(graphType, instrument){
        if(App.IsFirstLaunch){
            App.CurrentPlatform = (navigator.userAgent.indexOf('Mobile') > 0) ? 'Mobile' : 'PC';
            App.TimezoneOffset = new Date().getTimezoneOffset()*60*1000;
            App.Debug.log('CurrentPlatform = ' + App.CurrentPlatform);
            App.Debug.log('currentTimezoneOffset = ' + App.TimezoneOffset + '(' + (App.TimezoneOffset/60/60/1000) + 'ч)')
            App.LoadGif = document.getElementById('gifbox');
            App.BtnZoomIn = document.getElementById('zoom-in');
            App.BtnZoomOut = document.getElementById('zoom-out');
            App.IsFirstLaunch = false;
        }
        
        instrument = (instrument !== undefined) ? App.findLastUsedInstrument(instrument) : App.Instrument.EUR;
        App.Debug.log('insrument = ', instrument.name);
        App.Debug.log(graphType);
        Data.Request.onXHRChanged();
        
        if(App.GraphType.FOOTPRINT === graphType){
            App.CurrentGraph = new FootPrintGraph();
            App.CurrentGraph.setTimeframe(Timeframe.getTimeframe('M1'));
        }else{
            App.CurrentGraph = new DeltaGraph();
            App.CurrentGraph.setDelta(DeltaVal.getDelta(100));
        }
        
        App.CurrentGraph.setInstrument(instrument);
        this.Canvas = document.getElementsByTagName("Canvas")[0];
        App.CurrentGraph.init(this.Canvas, function(){
             Ui.init();
        });
        if(this.Flag){
            this.addEventListeners();
            this.Flag = false;
        }
    },
    
    addEventListeners: function(){
        window.addEventListener('resize', function(){
            App.CurrentGraph.onResize();
        });
        window.addEventListener('keydown', function (e) {
            App.CurrentGraph.dragByButtons(e);
        });
        
        this.Canvas.addEventListener('mouseup', function (e) {
            App.CurrentGraph.onUp(e);
        });
        
        this.Canvas.addEventListener('mousedown', function (e) {
            if(App.CurrentPlatform === 'PC'){
                App.CurrentGraph.createSprite(e);
                App.CurrentGraph.onDown(e);
            }
            App.CurrentGraph.findAxes();
        });
        
        this.Canvas.addEventListener('mousemove', function (e) {
            App.CurrentGraph.onMove(e);
        });
        
        this.Canvas.addEventListener('wheel', function (e) {
            App.CurrentGraph.onZoom(e);
        });
        
        this.BtnZoomIn.addEventListener('mousedown', function (e) {
            App.CurrentGraph.zoomIn(4, {});
        });
        
        this.BtnZoomOut.addEventListener('mousedown', function (e) {
            App.CurrentGraph.zoomOut(4, {});
        });
        
        this.Canvas.addEventListener('touchstart', function(e){
            if(App.ClickForEvent){
                App.CurrentGraph.createSprite(e);
                this.ClickForEvent = false;
            }
            App.CurrentGraph.onDown(e);
        }.bind(App.CurrentGraph)); //тык пальцем по экрану
        
        this.Canvas.addEventListener('touchend', function(e){
            App.CurrentGraph.onUp(e);
        }); //отрыв пальчика от экрана
        
        this.Canvas.addEventListener('touchmove', function(e){
            App.CurrentGraph.onMove(e); 
        }); //движение пальчиком по экрану
    },
    
    Debug: {
        
        getMessage: function(mas) {
            var l = mas.length,
                str = '';
            for (var i = 0; i < l; i++) {
                if(typeof mas[i] === 'number'){
                    str += ' ';
                }
                str += mas[i];
            }
            /*var stack = new Error().stack;
            
            stack = stack.replace(/Error/, '');
            var ind1 = stack.search('init'),
                ind2 = stack.search('at w');
            stack = stack.slice(ind1 + 6, ind2 - 6);
            str += '\n' + stack;
            */
            return str;
        },
        
        log: function() {
            var str = this.getMessage(arguments);
            console.log(str);
        },
        
        error: function() {
            var str = this.getMessage(arguments);
            console.error(str);
        },
        
        warn: function() {
            var str = this.getMessage(arguments);
            console.warn(str);
        }
    },
};

var Timeframe = {
    getTimeframe: function(timeframe) {
        var reg = /\D+/ig,
            width = 120,
            value = timeframe,
            timePerSec = 0,
            timePerPX = 0;
        timeframe = timeframe.replace(reg, '');
        
        var isMin = 60 * 1000,
            isHour = 60 * isMin,
            isDay = 24 * isHour;
        
        switch(value[0]) {
            case 'M': timePerSec = isMin; break;
            case 'H': timePerSec = isHour; break;
            case 'D': timePerSec = isDay; break;
        }
        
        timePerSec *= timeframe;
        timePerPX = timePerSec / width;
        
        var ret = {
            val: value,
            ts: timePerSec,
            timePerPx: timePerPX
        };
        return ret;
    }
};

var DeltaVal = {
    getDelta: function(delta) {
        return parseInt(delta);
    }
};

window.onload = function(){
    try{
        App.init(App.GraphType.FOOTPRINT);
    }catch(e){
        alert('init problem');
        App.Debug.error(e);
    }
}